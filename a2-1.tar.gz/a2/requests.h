#ifndef _REQUESTS_H_
#define _REQUESTS_H_

typedef enum {UNKNOWN, READ, WRITE, MEETUP, DEBUG} pc_op_t;

#endif

#ifndef _SERVER_H_
#define _SERVER_H_

#define MAX_THREADS 16
#define OUTPUT_BUFFER_SIZE 200

#endif
